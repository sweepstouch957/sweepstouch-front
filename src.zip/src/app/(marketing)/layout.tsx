'use client';

export { MarketingLayout as default } from 'src/layouts/marketing';
