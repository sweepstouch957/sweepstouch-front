'use client';

import { ManageCirculars } from 'src/components/circulars/pages/ManageCirculars';

const ManageCircularsPage = () => {
  return <ManageCirculars />;
};

export default ManageCircularsPage;
