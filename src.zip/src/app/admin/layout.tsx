'use client';

export { Layout as default } from 'src/layouts';
