'use client';

import React from 'react';
import FileManager from 'src/components/application-ui/content-shells/file-manager/file-manager';
import { Layout } from 'src/layouts';

function Page(): React.JSX.Element {
  return <FileManager />;
}
export default Page;
