'use client';

import React from 'react';
import StoreFrontListing from 'src/components/application-ui/content-shells/storefront/storefront';
import { Layout } from 'src/layouts';

function Page(): React.JSX.Element {
  return <StoreFrontListing />;
}
export default Page;
