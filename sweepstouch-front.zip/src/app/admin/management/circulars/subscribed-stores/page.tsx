'use client';

import { SubscribedStores } from 'src/components/circulars/pages/SubscribedStores';

const SubscribedStoresPage = () => {
  return <SubscribedStores />;
};

export default SubscribedStoresPage;
