'use client';

import { EditCircularsUpload } from 'src/components/circulars/pages/EditCircularsUpload';

const EditCircularsPage = () => {
  return <EditCircularsUpload />;
};

export default EditCircularsPage;
