'use client';

import { Box, Card, CardActionArea, Container, Divider, Stack, Typography } from '@mui/material';
import { Breakpoint } from '@mui/system';
import { useState } from 'react';
import { CopyToClipboard } from 'react-copy-to-clipboard';
import toast from 'react-hot-toast';
import { useTranslation } from 'react-i18next';
import ApplicationUiSkeletonAnimation from 'src/components/application-ui/skeleton/animation/animation';
import ApplicationUiSkeletonBasic from 'src/components/application-ui/skeleton/basic/basic';
import ApplicationUiSkeletonColor from 'src/components/application-ui/skeleton/color/color';
import ApplicationUiSkeletonPulsate from 'src/components/application-ui/skeleton/pulsate/pulsate';
import ApplicationUiSkeletonWave from 'src/components/application-ui/skeleton/wave/wave';
import { Helmet } from 'src/components/base/helmet';
import MarketingPageTitle from 'src/components/website/page-title';
import { MarketingLayout as Layout } from 'src/layouts/marketing';

const components: {
  element: JSX.Element;
  sourceCode?: string;
  title: string;
  isComplex: string;
  size: string;
  description: string;
  height: string;
  category: string;
}[] = [
  {
    element: <ApplicationUiSkeletonAnimation />,
    title: 'Animation',
    isComplex: 'false',
    size: 'xs',
    description: 'Skeleton screen with animation effects for a dynamic loading experience.',
    height: '',
    category: 'skeleton',
  },
  {
    element: <ApplicationUiSkeletonBasic />,
    title: 'Basic',
    isComplex: 'false',
    size: 'xs',
    description:
      'A basic skeleton screen layout, providing a placeholder while content is loading.',
    height: '',
    category: 'skeleton',
  },
  {
    element: <ApplicationUiSkeletonColor />,
    title: 'Color',
    isComplex: 'false',
    size: 'xs',
    description: 'Skeleton screen featuring color variations to match different design themes.',
    height: '',
    category: 'skeleton',
  },
  {
    element: <ApplicationUiSkeletonPulsate />,
    title: 'Pulsate',
    isComplex: 'false',
    size: 'md',
    description:
      'Skeleton screen with a pulsating effect, indicating content is in the process of loading.',
    height: '',
    category: 'skeleton',
  },
  {
    element: <ApplicationUiSkeletonWave />,
    title: 'Wave',
    isComplex: 'false',
    size: 'xs',
    description:
      'A skeleton screen with a wave-like loading animation for a visually engaging placeholder.',
    height: '',
    category: 'skeleton',
  },
];
const Page = () => {
  const {
    t,
  }: {
    t: any;
  } = useTranslation();
  const pageTitle = 'Skeleton';
  const pageDescription =
    'See our skeleton placeholders, providing a preview layout while content is loading, enhancing the user perception of speed.';
  const formatTitle = (title: string) => {
    return title.replace(/([A-Z])/g, ' $1');
  };
  const pageTitleDisplay = formatTitle(pageTitle);
  function generateSrcPath(title: string, category?: string): string {
    const processString = (str: string) => {
      return str
        .replace(/([A-Z])/g, ' $1')
        .trim()
        .toLowerCase()
        .replace(/[\s]+/g, '-');
    };
    const processedTitle = processString(title);
    let processedCategory = category && processString(category);
    return `/src/components/application-ui/${processedTitle}/${processedCategory}/`;
  }
  const [isCopied, setIsCopied] = useState(false);
  const handleCopy = () => {
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
    toast.success('Component path copied to clipboard');
  };
  return (
    <>
      <Helmet heading={t(pageTitleDisplay)} />
      <MarketingPageTitle
        title={t(pageTitleDisplay)}
        subheading={t(pageDescription)}
      />
      <Box
        py={{
          xs: 2,
          md: 3,
        }}
      >
        <Container maxWidth="xl">
          <Stack
            spacing={{
              xs: 3,
              sm: 4,
              md: 5,
            }}
            divider={<Divider />}
          >
            {components.map((component) => (
              <Card
                key={component.title}
                elevation={0}
                variant="outlined"
                sx={{
                  borderWidth: 2,
                  boxShadow: (theme) => `0 0 0 6px ${theme.palette.divider}`,
                  borderColor: (theme) =>
                    theme.palette.mode === 'dark' ? 'neutral.700' : 'neutral.500',
                  pb:
                    (component.size as Breakpoint) !== 'xl'
                      ? {
                          xs: 2,
                          sm: 3,
                        }
                      : undefined,
                }}
              >
                <Box
                  p={{
                    xs: 2,
                    sm: 3,
                  }}
                  mb={
                    (component.size as Breakpoint) !== 'xl'
                      ? {
                          xs: 2,
                          sm: 3,
                        }
                      : undefined
                  }
                  sx={{
                    backgroundColor: 'background.default',
                  }}
                >
                  <Typography variant="h4">{formatTitle(component.title)}</Typography>
                  {component.description && (
                    <Typography
                      variant="h5"
                      fontWeight={400}
                      color="text.secondary"
                    >
                      {component.description}
                    </Typography>
                  )}
                  <Box
                    mt={{
                      xs: 1,
                      sm: 2,
                    }}
                    display="flex"
                  >
                    <Card
                      elevation={0}
                      variant="outlined"
                    >
                      <CopyToClipboard
                        text={generateSrcPath(component.category, component.title)}
                        onCopy={handleCopy}
                      >
                        <CardActionArea
                          sx={{
                            py: 1,
                            px: 1.5,
                          }}
                        >
                          <Typography
                            variant="h6"
                            component="span"
                          >
                            {generateSrcPath(component.category, component.title)}
                          </Typography>
                        </CardActionArea>
                      </CopyToClipboard>
                    </Card>
                  </Box>
                </Box>
                <Container
                  disableGutters
                  maxWidth={component.size as Breakpoint}
                >
                  {component.element}
                </Container>
              </Card>
            ))}
          </Stack>
        </Container>
      </Box>
    </>
  );
};
export default Page;
