import CheckboxCardsGridHidden from './cards-group-grid';

const Component = () => {
  return <CheckboxCardsGridHidden />;
};

export default Component;
