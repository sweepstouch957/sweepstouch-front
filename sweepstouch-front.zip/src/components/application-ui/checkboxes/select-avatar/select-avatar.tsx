import { Card } from '@mui/material';
import SelectList from './select-avatar-list';

const Component = () => {
  return (
    <Card>
      <SelectList />
    </Card>
  );
};

export default Component;
