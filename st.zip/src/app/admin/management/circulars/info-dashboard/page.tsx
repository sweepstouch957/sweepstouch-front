'use client';

import { InfoDashboard } from 'src/components/circulars/pages/InfoDashboard';

const InfoDashboardPage = () => {
  return <InfoDashboard />;
};

export default InfoDashboardPage;
