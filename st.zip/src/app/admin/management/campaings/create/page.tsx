'use client';

import React from 'react';
import CampaignsCreate from 'src/components/application-ui/form-layouts/campaings/create-campaign';

function Page(): React.JSX.Element {
  return <CampaignsCreate />;
}
export default Page;
