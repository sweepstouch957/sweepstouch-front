'use client';

import React from 'react';
import UserProfile from 'src/components/application-ui/content-shells/user-profile/user-profile';
import { Layout } from 'src/layouts';

function Page(): React.JSX.Element {
  return <UserProfile />;
}
export default Page;
