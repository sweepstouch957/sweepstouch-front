import ApplicationUiAvatarsWithBadge from 'src/components/application-ui/avatars/with-badge/with-badge';

const Component = () => {
  return (
    <>
      <ApplicationUiAvatarsWithBadge />
    </>
  );
};

export default Component;
