'use client';

import { ScheduleCirculars } from 'src/components/circulars/pages/ScheduleCirculars';

const ScheduleCircularsPage = () => {
  return <ScheduleCirculars />;
};

export default ScheduleCircularsPage;
