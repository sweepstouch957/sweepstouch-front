'use client';

import { ScheduleCirculars } from "@/components/circulars/ScheduleCirculars";


const ScheduleCircularsPage = () => {
  return <ScheduleCirculars />;
};

export default ScheduleCircularsPage;
