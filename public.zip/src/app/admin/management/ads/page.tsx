'use client';

import { PromoDashboard } from '@/components/application-ui/tables/promos/panel';

import React from 'react';

function Page(): React.JSX.Element {
  return (
    <>
      <PromoDashboard />
    </>
  );
}

export default Page;
