'use client';

import React from 'react';
import ProductCreate from 'src/components/application-ui/form-layouts/create-product/create-product';
import { Layout } from 'src/layouts';

function Page(): React.JSX.Element {
  return <ProductCreate />;
}
export default Page;
