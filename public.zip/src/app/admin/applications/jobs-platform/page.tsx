'use client';

import React from 'react';
import JobsPlatform from 'src/components/application-ui/content-shells/jobs-platform/jobs-platform';
import { Layout } from 'src/layouts';

function Page(): React.JSX.Element {
  return <JobsPlatform />;
}
export default Page;
