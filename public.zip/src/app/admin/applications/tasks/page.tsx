'use client';

import React from 'react';
import Tasks from 'src/components/application-ui/content-shells/tasks/tasks';
import { Layout } from 'src/layouts';

function Page(): React.JSX.Element {
  return <Tasks />;
}
export default Page;
